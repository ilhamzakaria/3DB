<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Controllers\Produksi;

/**
 * API endpoint for Realtime Production Monitor
 * GET /api/realtime/produksi-live
 */
class RealtimeProduksiApi extends BaseController
{
    public function live()
    {
        try {
            $db    = $this->dbProduksi();
            $today = date('Y-m-d');

            $mesinLabels = Produksi::mesinLabels();
            $result      = [];

            foreach ($mesinLabels as $slug => $label) {
                // nama_mesin stored exactly as the label (e.g. "Becum", "Powerjet 1")
                $row = $db->table('produksi_headers')
                    ->where('tanggal', $today)
                    ->where('deleted_at', null)
                    ->like('nama_mesin', $label, 'none')
                    ->orderBy('id', 'DESC')
                    ->limit(1)
                    ->get()
                    ->getFirstRow('array');

                if ($row) {
                    $result[] = [
                        'slug'             => $slug,
                        'label'            => $label,
                        'status'           => 'running',
                        'nomor_spk'        => $row['no_spk']           ?? '-',
                        'nama_produk'      => $row['nama_produk']       ?? '-',
                        'brand'            => $row['brand']             ?? '-',
                        'operator'         => $row['operator']          ?? '-',
                        'shift'            => $row['shift']             ?? '-',
                        'grand_total_bagus'=> (int)($row['grand_total_bagus']  ?? 0),
                        'grand_total_reject'=> (int)($row['grand_total_reject'] ?? 0),
                        'sisa_po'          => (int)($row['sisa_po']    ?? 0),
                        'total_spk'        => (int)($row['total_spk']  ?? 0),
                        'target'           => (int)($row['target']     ?? 0),
                        'selesai_spk'      => (int)($row['selesai_spk'] ?? 0),
                        'tanggal'          => $row['tanggal']           ?? $today,
                    ];
                } else {
                    $result[] = [
                        'slug'             => $slug,
                        'label'            => $label,
                        'status'           => 'idle',
                        'nomor_spk'        => '-',
                        'nama_produk'      => '-',
                        'brand'            => '-',
                        'operator'         => '-',
                        'shift'            => '-',
                        'grand_total_bagus' => 0,
                        'grand_total_reject'=> 0,
                        'sisa_po'          => 0,
                        'total_spk'        => 0,
                        'target'           => 0,
                        'selesai_spk'      => 0,
                        'tanggal'          => $today,
                    ];
                }
            }

            return $this->response
                ->setContentType('application/json')
                ->setJSON(['success' => true, 'data' => $result, 'updated_at' => date('H:i:s')]);

        } catch (\Throwable $e) {
            log_message('error', '[RealtimeProduksiApi] ' . $e->getMessage());
            return $this->response
                ->setStatusCode(500)
                ->setContentType('application/json')
                ->setJSON(['success' => false, 'message' => 'Gagal mengambil data']);
        }
    }
}
