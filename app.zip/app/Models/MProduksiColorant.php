<?php

namespace App\Models;

use CodeIgniter\Model;

class MProduksiColorant extends BaseProduksiModel
{
    protected $table            = 'produksi_colorants';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'produksi_header_id', 'code', 'nomor_lot', 'pemakaian', 'tb_in', 'tb_out',
        'tb_in_details', 'tb_out_details', 'tb_lain_in', 'tb_lain_in_details', 'tb_in_runner', 'tb_out_runner'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
}
