<?php

namespace App\Models;

use CodeIgniter\Model;

class MProduksiHeader extends BaseProduksiModel
{
    protected $table            = 'produksi_headers';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'no_spk', 'nama_mesin', 'nama_produk', 'batch_number', 'type_produk', 'shift', 'grup',
        'nomor_mesin', 'packing', 'cycle_time', 'target', 'isi', 'tanggal', 
        'operator', 'catatan', 'brand', 'warna', 'grade', 'total_spk',
        'grand_total_bagus', 'grand_total_reject', 
        'total_downtime', 'sisa_po', 'hold', 'gumpalan', 'plash_kotor', 'sapuan',
        'counter_awal', 'counter_akhir', 'total_counter',
        'selesai_spk', 'tercapai',
        'ttd_shift_1', 'ttd_shift_2', 'ttd_shift_3', 'ttd_spv', 'auto_user_ttd',
        'extra_realisasi_shifts'
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
}
