<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<?php
$statusLabels = ['menggiling' => 'Menggiling', 'bahan_masuk' => 'Bahan Masuk', 'bahan_keluar' => 'Bahan Keluar'];
$statusBadges = ['menggiling' => 'badge-warning', 'bahan_masuk' => 'badge-success', 'bahan_keluar' => 'badge-info'];
$formatDate = static function ($value): string {
    $timestamp = $value ? strtotime((string) $value) : false;
    return $timestamp ? date('d-m-Y', $timestamp) : '-';
};
?>

<style>
    .filter-sidebar { position: fixed; top: 0; right: -350px; width: 350px; height: 100vh; background: #fff; z-index: 1100; box-shadow: -5px 0 15px rgba(0,0,0,0.1); transition: all 0.3s ease; display: flex; flex-direction: column; }
    .filter-sidebar.active { right: 0; }
    .filter-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.5); z-index: 1090; display: none; backdrop-filter: blur(2px); }
    .filter-overlay.active { display: block; }
    .filter-header { padding: 1.25rem; border-bottom: 1px solid #e3e6f0; display: flex; justify-content: space-between; align-items: center; background: #f8f9fc; }
    .filter-body { padding: 1.5rem; flex-grow: 1; overflow-y: auto; }
    .filter-footer { padding: 1.25rem; border-top: 1px solid #e3e6f0; background: #f8f9fc; display: flex; gap: 10px; }
    .filter-chip { display: inline-flex; align-items: center; background: #eaecf4; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.85rem; margin-right: 0.5rem; margin-bottom: 0.5rem; }
</style>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="d-flex flex-wrap align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <a href="<?= base_url('gudang') ?>" class="btn btn-secondary btn-sm mr-2">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
                <?php if (in_array(session()->get('role'), ['gudang', 'admin'], true)) : ?>
                    <button class="btn btn-primary btn-sm mr-2" data-toggle="modal" data-target="#addDataModal">
                        <i class="fas fa-plus"></i> Tambah Data
                    </button>
                <?php endif; ?>
                <button class="btn btn-outline-primary btn-sm" onclick="toggleFilter(true)">
                    <i class="fas fa-filter"></i> Filter
                    <?php if (!empty($start_date) || !empty($end_date)) : ?>
                        <span class="badge badge-primary ml-1">!</span>
                    <?php endif; ?>
                </button>
            </div>

            <form method="get" action="<?= base_url('gudang/stiker') ?>" class="d-flex align-items-center mb-0 mt-2 mt-md-0">
                <div class="input-group input-group-sm">
                    <input type="text" name="q" class="form-control" style="min-width: 200px;" placeholder="Cari data..." value="<?= esc($q ?? '') ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <?php if (!empty($start_date) || !empty($end_date)) : ?>
            <div class="mt-3">
                <small class="text-muted mr-2">Filter aktif:</small>
                <?php if (!empty($start_date)) : ?><span class="filter-chip">Mulai: <?= esc($start_date) ?></span><?php endif; ?>
                <?php if (!empty($end_date)) : ?><span class="filter-chip">Selesai: <?= esc($end_date) ?></span><?php endif; ?>
                <a href="<?= base_url('gudang/stiker') ?>" class="text-danger small ml-2"><i class="fas fa-times"></i> Reset</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="card-body">
        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success alert-dismissible fade show"><?= session()->getFlashdata('success') ?><button type="button" class="close" data-dismiss="alert">&times;</button></div>
        <?php endif; ?>

        <?php if (!empty($stiker_catalog)) : ?>
            <div class="mb-3">
                <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
                    <label class="mb-0 small font-weight-bold text-muted">Dropdown data dari catatan.md</label>
                    <small class="text-muted"><?= count($stiker_catalog) ?> item</small>
                </div>
                <select class="form-control form-control-sm">
                    <option value="">-- Pilih item untuk melihat daftar catatan --</option>
                    <?php foreach ($stiker_catalog as $catalog) : ?>
                        <option value="<?= esc($catalog['item']) ?>"><?= esc($catalog['label']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered text-center" width="100%" cellspacing="0">
                <thead>
                    <tr class="font-weight-bold">
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>Item</th>
                        <th>Status</th>
                        <th>Kode</th>
                        <th>Jumlah</th>
                        <th>Lot</th>
                        <th>SPK</th>
                        <th>Shift</th>
                        <th>#</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($data_list)) : ?>
                        <?php foreach ($data_list as $item) : ?>
                            <tr>
                                <td><?= esc($formatDate($item['tanggal'])) ?></td>
                                <td><?= esc($item['produk'] ?? '-') ?></td>
                                <td><?= esc($item['nama_stiker'] ?? '-') ?></td>
                                <td><span class="badge <?= esc($statusBadges[$item['status']] ?? 'badge-secondary') ?>"><?= esc($statusLabels[$item['status']] ?? $item['status']) ?></span></td>
                                <td><?= esc($item['kode'] ?? '-') ?></td>
                                <td><?= esc($item['jumlah'] ?? '-') ?></td>
                                 <td><?= esc($item['nomor_lot'] ?? '-') ?></td>
                                 <td>
                                     <button type="button" class="btn btn-sm btn-link btn-spk-produksi-autofill p-0" data-spk="<?= esc($item['no_spk'] ?? '') ?>" style="text-decoration: none; color: #4361ee;">
                                         <?= esc($item['no_spk'] ?? '-') ?>
                                     </button>
                                 </td>
                                 <td><?= esc($item['shif'] ?? '-') ?></td>
                                 <td>
                                     <?php if (in_array(session()->get('role'), ['gudang', 'admin'], true)) : ?>
                                        <div class="d-flex gap-1 justify-content-center">
                                            <button type="button" class="btn btn-warning btn-sm" onclick="setEditModal(<?= htmlspecialchars(json_encode($item)) ?>)" data-toggle="modal" data-target="#editDataModal"><i class="fas fa-edit"></i></button>
                                            <button type="button" class="btn btn-danger btn-sm ml-1" onclick="setDeleteModal(<?= $item['id'] ?>, '<?= esc($item['nama_stiker']) ?>')" data-toggle="modal" data-target="#modalDelete"><i class="fas fa-trash"></i></button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="10">Tidak ada data</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modals same pattern as gilingangalon but names adjusted -->
<div class="modal fade" id="addDataModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Tambah Stiker</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <form action="<?= base_url('gudang/stiker/tambahData') ?>" method="post">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6"><div class="form-group"><label>Tanggal</label><input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= date('Y-m-d') ?>" required></div></div>
                        <div class="col-md-6"><div class="form-group"><label>No SPK</label><input type="number" class="form-control" name="no_spk"></div></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Produk <span class="text-danger">*</span></label>
                                <select class="form-control select2-stiker" id="produk" name="produk" required style="width: 100%;">
                                    <option value="">-- Pilih Produk --</option>
                                    <?php foreach (($stiker_products ?? []) as $index => $prod) : ?>
                                        <option value="<?= esc($prod) ?>" <?= $index === 0 ? 'selected' : '' ?>><?= esc($prod) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama Item <span class="text-danger">*</span></label>
                                <select class="form-control select2-stiker" id="nama_stiker" name="nama_stiker" required style="width: 100%;">
                                    <option value="">-- Pilih Nama Item --</option>
                                    <?php foreach (($stiker_catalog ?? []) as $catalog) : ?>
                                        <option value="<?= esc($catalog['item']) ?>"><?= esc($catalog['label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" name="status">
                            <?php foreach ($status_options as $opt) : ?><option value="<?= $opt ?>" <?= $opt == 'bahan_masuk' ? 'selected' : '' ?>><?= $statusLabels[$opt] ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-4"><div class="form-group"><label>Kode</label><input type="text" class="form-control" id="kode" name="kode"></div></div>
                        <div class="col-md-4"><div class="form-group"><label>Jumlah</label><input type="text" class="form-control" name="jumlah"></div></div>
                        <div class="col-md-4"><div class="form-group"><label>Shift</label><input type="text" class="form-control" name="shif"></div></div>
                    </div>
                    <div class="form-group"><label>Nomor Lot</label><input type="text" class="form-control" name="nomor_lot"></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editDataModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Edit Stiker</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <form id="formEdit" method="post">
                <?= csrf_field() ?><input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6"><div class="form-group"><label>Tanggal</label><input type="date" class="form-control" name="tanggal" id="edit_tanggal" required></div></div>
                        <div class="col-md-6"><div class="form-group"><label>No SPK</label><input type="number" class="form-control" name="no_spk" id="edit_spk"></div></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Produk <span class="text-danger">*</span></label>
                                <select class="form-control select2-stiker" id="edit_produk" name="produk" required style="width: 100%;">
                                    <option value="">-- Pilih Produk --</option>
                                    <?php foreach (($stiker_products ?? []) as $prod) : ?>
                                        <option value="<?= esc($prod) ?>"><?= esc($prod) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama Item <span class="text-danger">*</span></label>
                                <select class="form-control select2-stiker" id="edit_nama" name="nama_stiker" required style="width: 100%;">
                                    <option value="">-- Pilih Nama Item --</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" name="status" id="edit_status">
                            <?php foreach ($status_options as $opt) : ?><option value="<?= $opt ?>"><?= $statusLabels[$opt] ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-4"><div class="form-group"><label>Kode</label><input type="text" class="form-control" name="kode" id="edit_kode"></div></div>
                        <div class="col-md-4"><div class="form-group"><label>Jumlah</label><input type="text" class="form-control" name="jumlah" id="edit_jumlah"></div></div>
                        <div class="col-md-4"><div class="form-group"><label>Shift</label><input type="text" class="form-control" name="shif" id="edit_shif"></div></div>
                    </div>
                    <div class="form-group"><label>Nomor Lot</label><input type="text" class="form-control" name="nomor_lot" id="edit_lot"></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Update</button></div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDelete" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <form id="formDelete" method="post">
                <?= csrf_field() ?><input type="hidden" name="id" id="delete_id">
                <div class="modal-body text-center"><p id="delete_message"></p></div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button><button type="submit" class="btn btn-danger btn-sm">Hapus</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Sidebar Filter -->
<div class="filter-overlay" onclick="toggleFilter(false)"></div>
<div class="filter-sidebar">
    <div class="filter-header">
        <h5 class="m-0 font-weight-bold text-primary"><i class="fas fa-filter mr-2"></i> Filter Data</h5>
        <button type="button" class="close" onclick="toggleFilter(false)">&times;</button>
    </div>
    <form method="get" action="<?= base_url('gudang/stiker') ?>">
        <div class="filter-body">
            <input type="hidden" name="q" value="<?= esc($q ?? '') ?>">
            <div class="form-group">
                <label class="small font-weight-bold">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?= esc($start_date ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="small font-weight-bold">Tanggal Selesai</label>
                <input type="date" name="end_date" class="form-control" value="<?= esc($end_date ?? '') ?>">
            </div>
        </div>
        <div class="filter-footer">
            <a href="<?= base_url('gudang/stiker') ?>" class="btn btn-secondary flex-fill">Reset</a>
            <button type="submit" class="btn btn-primary flex-fill">Terapkan</button>
        </div>
    </form>
</div>

<script>
    function toggleFilter(show) {
        if (show) {
            $('.filter-sidebar').addClass('active');
            $('.filter-overlay').addClass('active');
        } else {
            $('.filter-sidebar').removeClass('active');
            $('.filter-overlay').removeClass('active');
        }
    }

    var stikerData = <?= json_encode($stiker_options ?? [], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;

    function getItemSelectId(prefix) {
        return prefix ? prefix + 'nama' : 'nama_stiker';
    }

    function populateItems(prefix, selectedValue = '') {
        var produkSelect = document.getElementById(prefix + 'produk');
        var itemSelect = document.getElementById(getItemSelectId(prefix));
        var $itemSelect = window.jQuery ? window.jQuery(itemSelect) : null;
        
        if (!itemSelect) {
            return;
        }

        itemSelect.innerHTML = '<option value="">-- Pilih Nama Item --</option>';
        
        if (produkSelect && produkSelect.value && stikerData[produkSelect.value]) {
            stikerData[produkSelect.value].forEach(function(opt) {
                var option = document.createElement('option');
                option.value = opt.item;
                option.textContent = opt.label || (opt.kode_barang ? opt.kode_barang + ' - ' + opt.item : opt.item);
                if (opt.item === selectedValue) {
                    option.selected = true;
                }
                itemSelect.appendChild(option);
            });
        } else {
            itemSelect.innerHTML = '<option value="">-- Pilih Produk Terlebih Dahulu --</option>';
        }

        if ($itemSelect && typeof window.jQuery.fn.select2 === 'function') {
            $itemSelect.trigger('change.select2');
        }
    }

    function autoFillKode(prefix) {
        var produkSelect = document.getElementById(prefix + 'produk');
        var itemSelect = document.getElementById(getItemSelectId(prefix));
        var kodeInput = document.getElementById(prefix + 'kode');
        
        if (produkSelect && itemSelect && produkSelect.value && stikerData[produkSelect.value]) {
            var selectedItem = itemSelect.value;
            var match = stikerData[produkSelect.value].find(function(opt) {
                return opt.item === selectedItem;
            });
            if (match) {
                if (kodeInput) kodeInput.value = match.kode_barang || '';
                return;
            }
        }
        
        if (kodeInput) kodeInput.value = '';
    }

    document.getElementById('produk').addEventListener('change', function() {
        populateItems('', '');
        autoFillKode('');
    });

    document.getElementById('nama_stiker').addEventListener('change', function() {
        autoFillKode('');
    });

    document.getElementById('edit_produk').addEventListener('change', function() {
        populateItems('edit_', '');
        autoFillKode('edit_');
    });

    document.getElementById('edit_nama').addEventListener('change', function() {
        autoFillKode('edit_');
    });

    function setEditModal(data) {
        $('#edit_id').val(data.id);
        $('#edit_tanggal').val(data.tanggal);
        $('#edit_spk').val(data.no_spk);
        $('#edit_produk').val(data.produk);
        
        populateItems('edit_', data.nama_stiker);
        
        $('#edit_status').val(data.status);
        $('#edit_kode').val(data.kode);
        $('#edit_jumlah').val(data.jumlah);
        $('#edit_shif').val(data.shif);
        $('#edit_lot').val(data.nomor_lot);
        $('#formEdit').attr('action', '<?= base_url('gudang/stiker/update') ?>/' + data.id);

        if (window.jQuery && typeof window.jQuery.fn.select2 === 'function') {
            window.jQuery('#edit_produk').trigger('change.select2');
            window.jQuery('#edit_nama').trigger('change.select2');
        }
    }

    function setDeleteModal(id, nama) {
        $('#delete_id').val(id);
        $('#formDelete').attr('action', '<?= base_url('gudang/stiker/delete') ?>/' + id);
        $('#delete_message').text('Yakin ingin menghapus stiker "' + nama + '"?');
    }

    function initSelect2Stiker(modalSelector) {
        if (!window.jQuery || typeof window.jQuery.fn.select2 !== 'function') {
            return;
        }

        var $modal = window.jQuery(modalSelector);

        if (!$modal.length) {
            return;
        }

        $modal.find('select.select2-stiker').each(function() {
            var $select = window.jQuery(this);

            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }

            $select.select2({
                width: '100%',
                dropdownParent: $modal,
                minimumResultsForSearch: 0
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        var addModal = document.getElementById('addDataModal');
        var editModal = document.getElementById('editDataModal');

        populateItems('', '');
        populateItems('edit_', '');

        if (addModal && window.jQuery) {
            window.jQuery(addModal).on('shown.bs.modal', function() {
                initSelect2Stiker('#addDataModal');
            });

            window.jQuery(addModal).on('hidden.bs.modal', function() {
                var addForm = document.querySelector('form[action="<?= base_url('gudang/stiker/tambahData') ?>"]');
                if (addForm) {
                    addForm.reset();
                }
                var tanggalInput = document.getElementById('tanggal');
                if (tanggalInput) {
                    tanggalInput.value = '<?= date('Y-m-d') ?>';
                }
                populateItems('', '');
                if (window.jQuery && typeof window.jQuery.fn.select2 === 'function') {
                    window.jQuery('#produk').trigger('change.select2');
                }
            });
        }

        if (editModal && window.jQuery) {
            window.jQuery(editModal).on('shown.bs.modal', function() {
                initSelect2Stiker('#editDataModal');
            });
        }
    });
</script>
<?= view('shared/spk_produksi_autofill') ?>
<?= $this->endSection() ?>
