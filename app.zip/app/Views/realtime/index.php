<?= $this->extend('layout/main') ?>

<?= $this->section('vendor_styles') ?>
<style>
/* ── Page Layout ──────────────────────────────────────────── */
.realtime-page { padding: .5rem 0 2rem; }

.realtime-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: .75rem;
    margin-bottom: .75rem;
}

.realtime-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: .5rem;
    margin: 0;
}

.realtime-meta {
    display: flex;
    align-items: center;
    gap: .75rem;
    flex-wrap: wrap;
}

.last-update-badge {
    font-size: .72rem;
    color: #64748b;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
    padding: .25rem .75rem;
    display: flex;
    align-items: center;
    gap: .35rem;
}

.interval-badge {
    font-size: .72rem;
    color: #0369a1;
    background: #e0f2fe;
    border: 1px solid #bae6fd;
    border-radius: 20px;
    padding: .25rem .75rem;
    display: flex;
    align-items: center;
    gap: .35rem;
}

/* ── Card Grid ──────────────────────────────────────────────── */
.realtime-grid {
    display: grid;
    gap: 1rem;
}

.realtime-grid-4 { grid-template-columns: repeat(4, 1fr); }
.realtime-grid-5 { grid-template-columns: repeat(5, 1fr); }

@media (max-width: 1200px) {
    .realtime-grid-4 { grid-template-columns: repeat(2, 1fr); }
    .realtime-grid-5 { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
    .realtime-grid-4,
    .realtime-grid-5 { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
    .realtime-grid-4,
    .realtime-grid-5 { grid-template-columns: 1fr; }
}

/* ── Machine Card ───────────────────────────────────────────── */
.mesin-card {
    background: #fff;
    border-radius: 14px;
    border: 1.5px solid #e2e8f0;
    box-shadow: 0 1px 4px rgba(0,0,0,.06);
    overflow: hidden;
    transition: box-shadow .2s, border-color .2s;
}

.mesin-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.1); }

.mesin-card.running { border-color: #86efac; }
.mesin-card.idle    { border-color: #e2e8f0; }

/* card header bar */
.card-head {
    padding: .5rem .75rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: .5rem;
}

.mesin-card.running .card-head { background: linear-gradient(135deg,#ecfdf5 0%,#d1fae5 100%); }
.mesin-card.idle    .card-head { background: #f8fafc; }

.mesin-name {
    font-size: .88rem;
    font-weight: 700;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: .4rem;
}

.gear-icon { font-size: .95rem; color: #94a3b8; transition: color .3s; }
.mesin-card.running .gear-icon { color: #16a34a; }

/* status badge */
.status-badge {
    font-size: .68rem;
    font-weight: 700;
    border-radius: 20px;
    padding: .22rem .65rem;
    display: flex;
    align-items: center;
    gap: .3rem;
    white-space: nowrap;
}

.status-badge.running {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #86efac;
}

.status-badge.idle {
    background: #f1f5f9;
    color: #94a3b8;
    border: 1px solid #e2e8f0;
}

/* pulse dot for running */
.pulse-dot {
    width: 7px; height: 7px;
    border-radius: 50%;
    background: #22c55e;
    display: inline-block;
    animation: pulse-ring 1.4s ease-out infinite;
}

@keyframes pulse-ring {
    0%   { box-shadow: 0 0 0 0 rgba(34,197,94,.5); }
    70%  { box-shadow: 0 0 0 5px rgba(34,197,94,0); }
    100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
}

/* card body rows */
.card-body-rows { padding: .4rem .75rem .55rem; }

.data-row {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    padding: .15rem 0;
    border-bottom: 1px solid #f1f5f9;
    gap: .5rem;
}

.data-row:last-child { border-bottom: none; }

.data-label {
    font-size: .7rem;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: .4px;
    white-space: nowrap;
    flex-shrink: 0;
    font-weight: 700;
}

.data-value {
    font-size: .82rem;
    font-weight: 600;
    color: #1e293b;
    text-align: right;
    word-break: break-word;
}

.data-value.highlight { color: #0ea5e9; }
.data-value.success   { color: #16a34a; }
.data-value.danger    { color: #dc2626; }
.data-value.muted     { color: #94a3b8; font-weight: 400; }

/* selesai spk badge */
.spk-done { font-size: .65rem; background: #dcfce7; color: #15803d; border-radius: 6px; padding: .1rem .4rem; margin-left: .3rem; }

/* skeleton shimmer */
.shimmer {
    background: linear-gradient(90deg,#f1f5f9 25%,#e2e8f0 50%,#f1f5f9 75%);
    background-size: 200% 100%;
    animation: shimmer-move 1.2s infinite;
    border-radius: 4px;
    display: inline-block;
    height: .8rem;
    width: 60%;
}

@keyframes shimmer-move {
    0%   { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}

/* error toast */
.realtime-toast {
    position: fixed;
    bottom: 1.5rem;
    right: 1.5rem;
    background: #fef2f2;
    border: 1px solid #fca5a5;
    color: #b91c1c;
    border-radius: 10px;
    padding: .65rem 1rem;
    font-size: .8rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: .5rem;
    box-shadow: 0 4px 16px rgba(0,0,0,.12);
    z-index: 9999;
    opacity: 0;
    transform: translateY(12px);
    transition: opacity .3s, transform .3s;
    pointer-events: none;
}

.realtime-toast.show { opacity: 1; transform: translateY(0); }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="realtime-page">

    <!-- Header -->
    <div class="realtime-header">
        <h1 class="realtime-title">
            <i class="fas fa-bolt text-warning"></i> Monitor Produksi Realtime
        </h1>
        <div class="realtime-meta">
            <div class="interval-badge">
                <i class="fas fa-sync-alt"></i> Refresh tiap <span id="countdown">30</span>s
            </div>
            <div class="last-update-badge">
                <i class="fas fa-clock"></i> Update: <span id="lastUpdate">—</span>
            </div>
        </div>
    </div>

    <!-- Row 1: 4 card -->
    <div class="realtime-grid realtime-grid-4" id="realtimeGrid">
        <?php $i = 0; foreach ($mesinLabels as $slug => $label): if ($i >= 4) break; $i++; ?>
        <div class="mesin-card idle" id="card-<?= $slug ?>">
            <!-- Head -->
            <div class="card-head">
                <div class="mesin-name">
                    <i class="fas fa-cog gear-icon" id="gear-<?= $slug ?>"></i>
                    <?= esc($label) ?>
                </div>
                <span class="status-badge idle" id="badge-<?= $slug ?>">
                    <i class="fas fa-minus-circle"></i> Idle
                </span>
            </div>
            <!-- Body -->
            <div class="card-body-rows" id="body-<?= $slug ?>">
                <div class="data-row"><span class="data-label">SPK</span><span class="data-value highlight shimmer" id="spk-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Produk</span><span class="data-value shimmer" id="produk-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Operator</span><span class="data-value shimmer" id="operator-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Hasil Bagus</span><span class="data-value success shimmer" id="bagus-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Total Reject</span><span class="data-value danger shimmer" id="reject-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Sisa PO</span><span class="data-value shimmer" id="sisapo-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Total SPK</span><span class="data-value shimmer" id="totalspk-<?= $slug ?>"></span></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Row 2: 5 card -->
    <div class="realtime-grid realtime-grid-5 mt-3">
        <?php $i = 0; foreach ($mesinLabels as $slug => $label): if ($i++ < 4) continue; ?>
        <div class="mesin-card idle" id="card-<?= $slug ?>">
            <!-- Head -->
            <div class="card-head">
                <div class="mesin-name">
                    <i class="fas fa-cog gear-icon" id="gear-<?= $slug ?>"></i>
                    <?= esc($label) ?>
                </div>
                <span class="status-badge idle" id="badge-<?= $slug ?>">
                    <i class="fas fa-minus-circle"></i> Idle
                </span>
            </div>
            <!-- Body -->
            <div class="card-body-rows" id="body-<?= $slug ?>">
                <div class="data-row"><span class="data-label">SPK</span><span class="data-value highlight shimmer" id="spk-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Produk</span><span class="data-value shimmer" id="produk-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Operator</span><span class="data-value shimmer" id="operator-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Hasil Bagus</span><span class="data-value success shimmer" id="bagus-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Total Reject</span><span class="data-value danger shimmer" id="reject-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Sisa PO</span><span class="data-value shimmer" id="sisapo-<?= $slug ?>"></span></div>
                <div class="data-row"><span class="data-label">Total SPK</span><span class="data-value shimmer" id="totalspk-<?= $slug ?>"></span></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Error Toast -->
<div class="realtime-toast" id="errorToast">
    <i class="fas fa-exclamation-triangle"></i>
    <span id="errorMsg">Gagal memperbarui data</span>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
(function () {
    'use strict';

    const API_URL      = '<?= base_url('api/realtime/produksi-live') ?>';
    const INTERVAL_SEC = 30;

    let countdown     = INTERVAL_SEC;
    let intervalTimer = null;
    let toastTimer    = null;
    // Track previous values for change animation
    const prevValues  = {};

    // ── Helpers ──────────────────────────────────────────────────
    function fmt(n) {
        return Number(n).toLocaleString('id-ID');
    }

    function shiftLabel(s) {
        if (!s || s === '-' || s === '0') return '-';
        if (String(s).startsWith('extra_')) return 'Extra ' + s.replace('extra_', '');
        return 'Shift ' + s;
    }

    function el(id) { return document.getElementById(id); }

    // ── Toast ─────────────────────────────────────────────────────
    function showToast(msg) {
        const toast = el('errorToast');
        el('errorMsg').textContent = msg || 'Gagal memperbarui data';
        toast.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toast.classList.remove('show'), 4000);
    }

    // ── Shimmer helpers ──────────────────────────────────────────
    function setShimmer(id) {
        const e = el(id);
        if (e) { e.textContent = ''; e.classList.add('shimmer'); }
    }

    function clearShimmer(id, value, extraClass) {
        const e = el(id);
        if (!e) return;
        e.classList.remove('shimmer');
        if (extraClass) {
            e.className = 'data-value ' + extraClass;
        }
        // Animate change if value changed
        const prev = prevValues[id];
        if (prev !== undefined && prev !== value) {
            e.style.transition = 'color .1s';
            e.style.color = '#f59e0b';
            setTimeout(() => { e.style.color = ''; e.style.transition = ''; }, 600);
        }
        prevValues[id] = value;
        e.textContent = value;
    }

    // ── Update a single card ─────────────────────────────────────
    function updateCard(d) {
        const slug    = d.slug;
        const running = d.status === 'running';

        // Card container
        const card = el('card-' + slug);
        if (!card) return;
        card.className = 'mesin-card ' + d.status;

        // Gear icon spin
        const gear = el('gear-' + slug);
        if (gear) {
            gear.classList.toggle('fa-spin', running);
            gear.style.color = running ? '#16a34a' : '#94a3b8';
        }

        // Status badge
        const badge = el('badge-' + slug);
        if (badge) {
            badge.className = 'status-badge ' + d.status;
            if (running) {
                badge.innerHTML = '<span class="pulse-dot"></span> Running';
            } else {
                badge.innerHTML = '<i class="fas fa-minus-circle"></i> Idle';
            }
        }

        if (running) {
            const spkText = d.nomor_spk + (d.selesai_spk ? ' <span class="spk-done">✓ Selesai</span>' : '');
            const spkEl   = el('spk-' + slug);
            if (spkEl) {
                spkEl.classList.remove('shimmer');
                spkEl.className  = 'data-value highlight';
                spkEl.innerHTML  = spkText;
            }

            clearShimmer('produk-'    + slug, d.nama_produk   || '-', '');
            clearShimmer('operator-'  + slug, (d.operator || '-') + '  ' + shiftLabel(d.shift), 'muted');
            clearShimmer('bagus-'     + slug, fmt(d.grand_total_bagus) + ' pcs', 'success');
            clearShimmer('reject-'    + slug, fmt(d.grand_total_reject) + ' pcs', 'danger');
            clearShimmer('sisapo-'    + slug, fmt(d.sisa_po) + ' pcs', '');
            clearShimmer('totalspk-'  + slug, fmt(d.total_spk) + ' pcs', '');
        } else {
            // Idle state — clear shimmer with dashes
            ['spk','produk','operator','bagus','reject','sisapo','totalspk'].forEach(function(key) {
                const e = el(key + '-' + slug);
                if (e) { e.classList.remove('shimmer'); e.textContent = '—'; e.className = 'data-value muted'; }
            });
        }
    }

    // ── Fetch & update all ───────────────────────────────────────
    function fetchData() {
        fetch(API_URL)
            .then(function(r) {
                if (!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            })
            .then(function(json) {
                if (!json.success) throw new Error('API error');
                json.data.forEach(updateCard);
                const upd = el('lastUpdate');
                if (upd) upd.textContent = json.updated_at || new Date().toLocaleTimeString('id-ID');
            })
            .catch(function(err) {
                console.warn('[Realtime] fetch error:', err);
                showToast('Gagal memperbarui data — mencoba lagi dalam ' + countdown + 's');
            });
    }

    // ── Countdown ticker ────────────────────────────────────────
    function startCountdown() {
        countdown = INTERVAL_SEC;
        clearInterval(intervalTimer);
        intervalTimer = setInterval(function () {
            countdown--;
            const cdEl = el('countdown');
            if (cdEl) cdEl.textContent = countdown;
            if (countdown <= 0) {
                countdown = INTERVAL_SEC;
                fetchData();
            }
        }, 1000);
    }

    // ── Boot ─────────────────────────────────────────────────────
    fetchData();       // immediate first load
    startCountdown();  // then every 30s

})();
</script>
<?= $this->endSection() ?>
